<?php

use yii\helpers\Html;
use yii\grid\GridView;
use common\models\AdminPost;
use yii\helpers\ArrayHelper;
use common\models\OrderMaster;

/* @var $this yii\web\View */
/* @var $searchModel common\models\AdminUsersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
?>
<div class="dashboard">
    <div class="row">
        <div class="col-md-12">
            <h4>Dashboard</h4>
            <h6 style="color: #085d9e;">Take a tour</h6>
        </div>
    </div>
</div>



